#ifndef __CC_LOG_H_
#define __CC_LOG_H_

void cc_printf(const char* s, ...);

#endif